#!/bin/ksh
if [ `df -k / |grep -v used |cut -f 2 -d /` = dev ]
then
if [ `df -k / |grep -v used |cut -f 3 -d /` = vx ]
then
for i in `vxdisk -e -g rootdg list |grep -v STATUS |awk ' { print $6 } ' `
do echo $i
prtvtoc /dev/rdsk/$i
done
else
if [ `df -k / |grep -v used |cut -f 3 -d /` = md ]
then
for i in `df -k / |grep -v used |cut -f 5 -d / |awk ' { print $1 } '`
do
for m in `metastat $i |grep -i sd@ |cut -f 1 -d " "`
do
prtvtoc /dev/rdsk/"$m"s2
done
done
else
for n in `df -k |grep -v used |awk ' { print $1 } '`
do
prtvtoc $n
done
fi
fi
else
echo "root FS in ZFS"
fi
